-- creazione tabelle 

CREATE TABLE Category (
 IDCategory INT 
, CategoryName VARCHAR(25) 
, CONSTRAINT PK_Category PRIMARY KEY (IDCategory)) ;

create table Products (
IDProduct int
, ProductName varchar (25)
, IDCategory int
, constraint PK_Products primary key ( IDProduct)
, constraint FK_Category_Product foreign key (IDCategory)
references Category (IDCategory)) ;

create table Regions (
IDRegion int
, RegionName varchar (25)
, constraint PK_Regions primary key (IDRegion)) ;

create table States (
IDState int
, StateName varchar (25)
, IDRegion int
, constraint PK_States primary key (IDState)
, constraint FK_Codice_Regione foreign key (IDRegion)
references Regions (IDRegion));

create table Sales (
IDSale int
, SalesOrderNumber varchar (25)
, SalesAmount decimal (12,2)
, OrderDate date
, IDProduct int
, IDState int
, constraint PK_Sales primary key (IDSale)
, constraint FK_Codice_Prodotto foreign key (IDProduct)
references Products (IDProduct)
, constraint FK_Chiave_Stato foreign key (IDState)
references States (IDState));

-- popolamento tabelle

INSERT INTO Category (IDCategory, CategoryName) VALUES
(1, 'Bikes'),
(2, 'Clothing'),
(3, 'Accessories'),
(4, 'Toys'),
(5, 'Outdoor');

INSERT INTO Products (IDProduct, ProductName, IDCategory) VALUES
(101, 'Bike-100', 1),
(102, 'Bike Gloves L', 2),
(103, 'Helmet Pro', 3),
(104, 'Toy Car', 4),
(105, 'Tent Ultra', 5);

INSERT INTO Regions (IDRegion, RegionName) VALUES
(1, 'WestEurope'),
(2, 'SouthEurope'),
(3, 'NorthAmerica'),
(4, 'Asia'),
(5, 'Africa');

INSERT INTO States (IDState, StateName, IDRegion) VALUES
(1, 'France', 1),
(2, 'Germany', 1),
(3, 'Italy', 2),
(4, 'USA', 3),
(5, 'India', 4);

INSERT INTO Sales (IDSale, SalesOrderNumber, SalesAmount, OrderDate, IDProduct, IDState) VALUES
(1, 'SO101', 299.99, '2023-11-10', 101, 1),
(2, 'SO102', 49.90, '2024-03-01', 102, 3),
(3, 'SO103', 79.50, '2024-12-20', 103, 2),
(4, 'SO104', 15.00, '2025-01-15', 104, 4),
(5, 'SO105', 220.00, '2025-03-28', 105, 5);










