/* 1)	Verificare che i campi definiti come PK siano univoci. 
In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata). */

SELECT IDCategory
FROM Category
GROUP BY IDCategory
HAVING COUNT(*) > 1;

SELECT IDRegion
FROM regions
GROUP BY IDRegion
HAVING COUNT(*) > 1;

SELECT IDCategory
FROM Category
GROUP BY IDCategory
HAVING COUNT(*) > 1;

SELECT IDState
FROM states
GROUP BY IDState
HAVING COUNT(*) > 1;

SELECT IDSale
FROM sales
GROUP BY IDSale
HAVING COUNT(*) > 1;

/* 2)	Esporre l’elenco delle transazioni indicando nel result set 
il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione 
che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) */

SELECT 
s.SalesOrderNumber
,s.OrderDate
,p.ProductName
,c.CategoryName
,st.StateName
,r.RegionName,
CASE WHEN DATEDIFF(CURDATE(), s.OrderDate) > 180 THEN TRUE
ELSE FALSE
END AS Over180Days
FROM Sales s
JOIN Products p ON s.IDProduct = p.IDProduct
JOIN Category c ON p.IDCategory = c.IDCategory
JOIN States st ON s.IDState = st.IDState
JOIN Regions r ON st.IDRegion = r.IDRegion;

/* 3)	Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite 
realizzate nell’ultimo anno censito. 
(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
Nel result set devono comparire solo il codice prodotto e il totale venduto. */

SELECT 
    p.IDProduct,
    SUM(s.SalesAmount) AS TotalSales
FROM Sales s
JOIN Products p ON s.IDProduct = p.IDProduct
GROUP BY p.IDProduct
HAVING SUM(s.SalesAmount) > (
SELECT AVG(SalesAmount)
FROM Sales
WHERE YEAR(OrderDate) = (
SELECT MAX(YEAR(OrderDate)) FROM Sales));
        
-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. */

SELECT 
p.IDProduct
,p.ProductName
,YEAR(s.OrderDate) AS SalesYear,
SUM(s.SalesAmount) AS TotalSales
FROM Sales s
JOIN Products p ON s.IDProduct = p.IDProduct
GROUP BY p.IDProduct, SalesYear
ORDER BY p.IDProduct, SalesYear;

-- 5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente

SELECT 
st.StateName
,YEAR(s.OrderDate) AS SalesYear
,SUM(s.SalesAmount) AS TotalSales
FROM Sales s
JOIN States st ON s.IDState = st.IDState
GROUP BY st.StateName, SalesYear
ORDER BY SalesYear, TotalSales DESC;

/* 6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
(prima di farlo ho aggiunto prodotti venduti alla mia tabella Sales, altrimenti ogni prodotto era vendeto sempre e solo uan volta*/

INSERT INTO Sales (IDSale, SalesOrderNumber, SalesAmount, OrderDate, IDProduct, IDState) VALUES
(6, 'SO106', 349.00, '2025-03-30', 101, 1)
, (7, 'SO106', 349.00, '2025-02-01', 101, 1) 
, (8, 'SO108', 89.90, '2025-04-02', 103, 2)
, (9, 'SO109', 25.00, '2025-04-03', 104, 4);

SELECT 
    c.CategoryName,
    COUNT(*) AS NumeroVendite
FROM Sales s
JOIN Products p ON s.IDProduct = p.IDProduct
JOIN Category c ON p.IDCategory = c.IDCategory
GROUP BY c.CategoryName
ORDER BY NumeroVendite DESC
LIMIT 1;

/* 7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.
(ho prima aggiunto prodotti invenduti) */

insert into products (IDProduct, ProductName, IDCategory) values
(106, 'Water Bottle', 3),
(107, 'Rain Jacket', 2);

SELECT p.IDProduct, p.ProductName
FROM Products p
LEFT JOIN Sales s ON p.IDProduct = s.IDProduct
WHERE s.IDProduct IS NULL;

/* 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” 
delle informazioni utili (codice prodotto, nome prodotto, nome categoria) */

CREATE VIEW vw_ProductDetails as 
SELECT 
    p.IDProduct,
    p.ProductName,
    c.CategoryName
FROM Products p
JOIN Category c ON p.IDCategory = c.IDCategory;

-- 9)	Creare una vista per le informazioni geografiche

CREATE VIEW VistaGeografica AS
SELECT 
    st.IDState,
    st.StateName,
    r.RegionName
FROM States st
JOIN Regions r ON st.IDRegion = r.IDRegion;



